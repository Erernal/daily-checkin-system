'use strict';

/* ==========================================================================
 *  防拖延强制打卡系统 · 后端服务
 * --------------------------------------------------------------------------
 *  技术栈：Node.js 18+ / Express 4 / better-sqlite3 / JWT
 *  职责：统一为 Web 管理端与 React Native App 提供 REST API
 *
 *  设计约定（务必与 App / Web 端保持一致）：
 *   1. “打卡日”按 timezone（默认 Asia/Shanghai）的日历日计算，格式 YYYY-MM-DD。
 *   2. 每个用户可自定义每日截止时间 deadline（HH:MM），未设置时使用全局默认值。
 *   3. 截止时间前打卡 = done；截止时间后当天打卡 = late（仍计入连胜）。
 *   4. 一整天既没打卡也没填借口 = 断签，连胜清零（下次请求时惰性结算）。
 *   5. 填借口 = 当天免于断签，但不计入打卡天数；同一天只能填一次。
 *   6. 强制阻断：当天过了截止时间仍未打卡 / 昨天漏签未处理时，blocked=true，
 *      App 端据此弹出全屏遮罩，必须提交借口才能继续使用。
 * ========================================================================== */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');

/* --------------------------------------------------------------------------
 * 1. 配置
 * ------------------------------------------------------------------------ */

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';

const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(__dirname, 'data', 'checkin.db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-please-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

const DEFAULT_TIMEZONE = process.env.APP_TIMEZONE || 'Asia/Shanghai';
const DEFAULT_DEADLINE = process.env.DEFAULT_DEADLINE || '22:00';

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

// 允许 App 端跨域调用；如需收紧，用 ALLOWED_ORIGINS="https://a.com,https://b.com"
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const EXCUSE_LOOKBACK_DAYS = 7; // 允许补填最近 7 天的借口
const LEADERBOARD_MAX = 200;

if (IS_PROD && JWT_SECRET === 'dev-only-secret-please-change-me') {
  console.warn('[warn] 生产环境请务必设置 JWT_SECRET 环境变量！');
}

/* --------------------------------------------------------------------------
 * 2. 数据库初始化（建表）
 * ------------------------------------------------------------------------ */

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    username          TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash     TEXT    NOT NULL,
    is_admin          INTEGER NOT NULL DEFAULT 0,
    deadline          TEXT,                     -- 个人截止时间 HH:MM，NULL = 跟随全局
    current_streak    INTEGER NOT NULL DEFAULT 0,
    best_streak       INTEGER NOT NULL DEFAULT 0,
    last_counted_date TEXT,                     -- 最近一次“计数日” YYYY-MM-DD（打卡或借口）
    created_at        TEXT    NOT NULL,
    updated_at        TEXT    NOT NULL
  );

  CREATE TABLE IF NOT EXISTS checkins (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    date       TEXT    NOT NULL,                -- 打卡日 YYYY-MM-DD
    late       INTEGER NOT NULL DEFAULT 0,      -- 1 = 迟于截止时间
    note       TEXT,
    created_at TEXT    NOT NULL,
    UNIQUE (user_id, date)
  );

  CREATE TABLE IF NOT EXISTS excuses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    date       TEXT    NOT NULL,                -- 被豁免的打卡日 YYYY-MM-DD
    reason     TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    UNIQUE (user_id, date)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id   INTEGER,
    action     TEXT NOT NULL,
    target_id  INTEGER,
    detail     TEXT,
    created_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_checkins_user_date ON checkins (user_id, date);
  CREATE INDEX IF NOT EXISTS idx_excuses_user_date  ON excuses (user_id, date);
`);

/* --------------------------------------------------------------------------
 * 3. 预编译语句
 * ------------------------------------------------------------------------ */

const q = {
  userById: db.prepare('SELECT * FROM users WHERE id = ?'),
  userByName: db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE'),
  allUsers: db.prepare('SELECT * FROM users ORDER BY id ASC'),
  insertUser: db.prepare(`
    INSERT INTO users (username, password_hash, is_admin, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
  `),
  updateUserDeadline: db.prepare('UPDATE users SET deadline = ?, updated_at = ? WHERE id = ?'),
  updateUserStreak: db.prepare(
    'UPDATE users SET current_streak = ?, last_counted_date = ?, updated_at = ? WHERE id = ?'
  ),
  updateUserBoth: db.prepare(`
    UPDATE users SET current_streak = ?, best_streak = ?, last_counted_date = ?, updated_at = ?
    WHERE id = ?
  `),
  updateUsername: db.prepare('UPDATE users SET username = ?, updated_at = ? WHERE id = ?'),
  updatePassword: db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?'),

  checkinOn: db.prepare('SELECT * FROM checkins WHERE user_id = ? AND date = ?'),
  insertCheckin: db.prepare(
    'INSERT INTO checkins (user_id, date, late, note, created_at) VALUES (?, ?, ?, ?, ?)'
  ),
  deleteCheckinOn: db.prepare('DELETE FROM checkins WHERE user_id = ? AND date = ?'),
  countCheckins: db.prepare('SELECT COUNT(*) AS n FROM checkins WHERE user_id = ?'),

  excuseOn: db.prepare('SELECT * FROM excuses WHERE user_id = ? AND date = ?'),
  insertExcuse: db.prepare(
    'INSERT INTO excuses (user_id, date, reason, created_at) VALUES (?, ?, ?, ?)'
  ),
  deleteExcuseOn: db.prepare('DELETE FROM excuses WHERE user_id = ? AND date = ?'),

  getSetting: db.prepare('SELECT value FROM settings WHERE key = ?'),
  setSetting: db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  ),
  audit: db.prepare(
    'INSERT INTO audit_log (actor_id, action, target_id, detail, created_at) VALUES (?, ?, ?, ?, ?)'
  ),
};

/* --------------------------------------------------------------------------
 * 4. 种子数据（全局设置 + 内置管理员）
 * ------------------------------------------------------------------------ */

const nowIso = () => new Date().toISOString();

function seed() {
  const defaults = {
    default_deadline: DEFAULT_DEADLINE,
    timezone: DEFAULT_TIMEZONE,
    site_name: '不拖延',
  };
  for (const [key, value] of Object.entries(defaults)) {
    if (!q.getSetting.get(key)) q.setSetting.run(key, value);
  }

  const existing = q.userByName.get(ADMIN_USERNAME);
  if (!existing) {
    q.insertUser.run(ADMIN_USERNAME, hashPassword(ADMIN_PASSWORD), 1, nowIso(), nowIso());
    console.log(`[seed] 已创建管理员账号：${ADMIN_USERNAME} / ${ADMIN_PASSWORD}`);
  } else if (existing.is_admin !== 1) {
    db.prepare('UPDATE users SET is_admin = 1 WHERE id = ?').run(existing.id);
  }
}

/* --------------------------------------------------------------------------
 * 5. 密码 / Token
 * ------------------------------------------------------------------------ */

const SCRYPT_KEYLEN = 64;

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(String(plain), salt, SCRYPT_KEYLEN).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

function verifyPassword(plain, stored) {
  try {
    const [scheme, salt, hash] = String(stored || '').split('$');
    if (scheme !== 'scrypt' || !salt || !hash) return false;
    const derived = crypto.scryptSync(String(plain), salt, SCRYPT_KEYLEN);
    const expected = Buffer.from(hash, 'hex');
    return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

function signToken(user) {
  return jwt.sign({ sub: String(user.id), adm: user.is_admin === 1 }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
}

/* --------------------------------------------------------------------------
 * 6. 时区与日期工具
 * ------------------------------------------------------------------------ */

const formatterCache = new Map();

function formatterFor(timeZone) {
  let fmt = formatterCache.get(timeZone);
  if (!fmt) {
    fmt = new Intl.DateTimeFormat('en-GB', {
      timeZone,
      hourCycle: 'h23',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    formatterCache.set(timeZone, fmt);
  }
  return fmt;
}

function isValidTimeZone(tz) {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function zonedParts(date, timeZone) {
  const parts = formatterFor(timeZone).formatToParts(date);
  const bag = {};
  for (const p of parts) if (p.type !== 'literal') bag[p.type] = p.value;
  return {
    year: Number(bag.year),
    month: Number(bag.month),
    day: Number(bag.day),
    hour: Number(bag.hour) % 24,
    minute: Number(bag.minute),
    second: Number(bag.second),
  };
}

const pad2 = (n) => String(n).padStart(2, '0');

function dateKey(date, timeZone) {
  const p = zonedParts(date, timeZone);
  return `${p.year}-${pad2(p.month)}-${pad2(p.day)}`;
}

function minutesOfDay(date, timeZone) {
  const p = zonedParts(date, timeZone);
  return p.hour * 60 + p.minute;
}

function secondsOfDay(date, timeZone) {
  const p = zonedParts(date, timeZone);
  return p.hour * 3600 + p.minute * 60 + p.second;
}

/** 'YYYY-MM-DD' 加减天数（纯字符串运算，不受时区影响） */
function addDays(key, delta) {
  const [y, m, d] = key.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d) + delta * 86400000);
  return `${t.getUTCFullYear()}-${pad2(t.getUTCMonth() + 1)}-${pad2(t.getUTCDate())}`;
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

function hhmmToMinutes(hhmm) {
  const [h, m] = String(hhmm).split(':').map(Number);
  return h * 60 + m;
}

/* --------------------------------------------------------------------------
 * 7. 业务规则实现
 * ------------------------------------------------------------------------ */

function getSetting(key, fallback = null) {
  const row = q.getSetting.get(key);
  return row ? row.value : fallback;
}

function appTimezone() {
  const tz = getSetting('timezone', DEFAULT_TIMEZONE);
  return isValidTimeZone(tz) ? tz : DEFAULT_TIMEZONE;
}

function defaultDeadline() {
  const value = getSetting('default_deadline', DEFAULT_DEADLINE);
  return TIME_RE.test(value) ? value : DEFAULT_DEADLINE;
}

function effectiveDeadline(user) {
  return user && TIME_RE.test(user.deadline || '') ? user.deadline : defaultDeadline();
}

/** 惰性结算：把 last_counted_date 推进到昨天，期间漏签则清零连胜 */
function settleUser(user, today, tz) {
  const marker = user.last_counted_date;
  if (!marker) return user;

  const yesterday = addDays(today, -1);
  if (marker >= yesterday) return user;

  let missed = false;
  let cursor = addDays(marker, 1);
  let guard = 0;
  while (cursor <= yesterday && guard < 400) {
    if (!q.checkinOn.get(user.id, cursor) && !q.excuseOn.get(user.id, cursor)) {
      missed = true;
    }
    cursor = addDays(cursor, 1);
    guard += 1;
  }

  const nextStreak = missed ? 0 : user.current_streak;
  q.updateUserStreak.run(nextStreak, yesterday, nowIso(), user.id);
  user.current_streak = nextStreak;
  user.last_counted_date = yesterday;
  return user;
}

/** 计算“今日状态”及强制阻断信息 */
function buildStatus(user, now = new Date()) {
  const tz = appTimezone();
  const today = dateKey(now, tz);
  const yesterday = addDays(today, -1);
  const deadline = effectiveDeadline(user);
  const nowMin = minutesOfDay(now, tz);
  const nowSec = secondsOfDay(now, tz);
  const deadlineMin = hhmmToMinutes(deadline);
  const passed = nowMin >= deadlineMin;

  const checkin = q.checkinOn.get(user.id, today);
  const excuse = q.excuseOn.get(user.id, today);

  let status;
  if (checkin) status = checkin.late === 1 ? 'late' : 'done';
  else if (excuse) status = 'excused';
  else if (passed) status = 'missed';
  else status = 'pending';

  // ---- 强制阻断判定 ----
  let blocked = false;
  let blockDate = null;
  let blockReason = null;

  if (!checkin && !excuse && passed) {
    blocked = true;
    blockDate = today;
    blockReason = 'TODAY_DEADLINE_PASSED';
  } else {
    const registeredAt = dateKey(new Date(user.created_at), tz);
    if (yesterday >= registeredAt && !q.checkinOn.get(user.id, yesterday) && !q.excuseOn.get(user.id, yesterday)) {
      blocked = true;
      blockDate = yesterday;
      blockReason = 'YESTERDAY_MISSED';
    }
  }

  const totalCheckins = q.countCheckins.get(user.id).n;

  return {
    user: {
      id: user.id,
      username: user.username,
      isAdmin: user.is_admin === 1,
      deadline: user.deadline,
    },
    today,
    timezone: tz,
    deadline,
    serverTime: now.toISOString(),
    status, // pending | done | late | excused | missed
    checkedIn: Boolean(checkin),
    checkedInAt: checkin ? checkin.created_at : null,
    late: Boolean(checkin && checkin.late === 1),
    excused: Boolean(excuse),
    excuseReason: excuse ? excuse.reason : null,
    streak: user.current_streak,
    bestStreak: user.best_streak,
    totalCheckins,
    blocked,
    blockDate,
    blockReason,
    deadlinePassed: passed,
    secondsUntilDeadline: passed
      ? 0
      : Math.max(0, deadlineMin * 60 - nowSec),
  };
}

function serializeUser(user) {
  return {
    id: user.id,
    username: user.username,
    isAdmin: user.is_admin === 1,
    deadline: user.deadline,
    streak: user.current_streak,
    bestStreak: user.best_streak,
    lastCountedDate: user.last_counted_date,
    createdAt: user.created_at,
  };
}

function publicError(res, status, code, message) {
  return res.status(status).json({ error: code, message });
}

/* --------------------------------------------------------------------------
 * 8. 简易登录限流（防止暴力破解）
 * ------------------------------------------------------------------------ */

const buckets = new Map();

function rateLimit({ key, limit, windowMs }) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now - b.start > windowMs) {
    b = { start: now, count: 0 };
    buckets.set(key, b);
  }
  b.count += 1;
  return b.count <= limit;
}

setInterval(() => {
  const now = Date.now();
  for (const [key, b] of buckets) if (now - b.start > 3600_000) buckets.delete(key);
}, 600_000).unref();

/* --------------------------------------------------------------------------
 * 9. Express 应用
 * ------------------------------------------------------------------------ */

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);

app.use(
  cors({
    origin: ALLOWED_ORIGINS.length ? ALLOWED_ORIGINS : true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    maxAge: 86400,
  })
);
app.use(express.json({ limit: '128kb' }));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  const started = process.hrtime.bigint();
  res.on('finish', () => {
    if (req.path.startsWith('/api')) {
      const ms = Number(process.hrtime.bigint() - started) / 1e6;
      console.log(
        `[api] ${req.method} ${req.originalUrl} -> ${res.statusCode} ${ms.toFixed(1)}ms`
      );
    }
  });
  next();
});

/** 认证中间件：Bearer Token -> req.user（每次都读库，保证改名/重置立刻生效） */
function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
  if (!token) return publicError(res, 401, 'UNAUTHORIZED', '请先登录');

  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET);
  } catch (err) {
    const expired = err && err.name === 'TokenExpiredError';
    return publicError(
      res,
      401,
      expired ? 'TOKEN_EXPIRED' : 'TOKEN_INVALID',
      expired ? '登录已过期，请重新登录' : '登录凭证无效'
    );
  }

  const user = q.userById.get(Number(payload.sub));
  if (!user) return publicError(res, 401, 'USER_NOT_FOUND', '账号不存在或已被删除');

  req.user = user;
  next();
}

function adminRequired(req, res, next) {
  if (!req.user || req.user.is_admin !== 1) {
    return publicError(res, 403, 'FORBIDDEN', '需要管理员权限');
  }
  next();
}

/** 统一刷新：结算断签 + 返回最新用户 */
function freshUser(user) {
  const tz = appTimezone();
  const today = dateKey(new Date(), tz);
  settleUser(user, today, tz);
  return user;
}

/* ------------------------------- 健康检查 -------------------------------- */

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    service: 'qiangzhi-checkin',
    version: '1.0.0',
    env: NODE_ENV,
    timezone: appTimezone(),
    now: new Date().toISOString(),
    uptimeSeconds: Math.round(process.uptime()),
  });
});

/* ------------------------------- 用户系统 -------------------------------- */

const USERNAME_RE = /^[a-zA-Z0-9_\u4e00-\u9fa5-]{2,24}$/;

function validateCredentials(username, password) {
  if (typeof username !== 'string' || !USERNAME_RE.test(username.trim())) {
    return '用户名需为 2-24 位字母、数字、下划线或中文';
  }
  if (typeof password !== 'string' || password.length < 6 || password.length > 72) {
    return '密码长度需为 6-72 位';
  }
  return null;
}

app.post('/api/register', (req, res) => {
  const ip = req.ip || 'unknown';
  if (!rateLimit({ key: `reg:${ip}`, limit: 20, windowMs: 3600_000 })) {
    return publicError(res, 429, 'TOO_MANY_REQUESTS', '注册过于频繁，请稍后再试');
  }

  const { username, password } = req.body || {};
  const problem = validateCredentials(username, password);
  if (problem) return publicError(res, 400, 'INVALID_INPUT', problem);

  const name = String(username).trim();
  if (q.userByName.get(name)) {
    return publicError(res, 409, 'USERNAME_TAKEN', '该用户名已被注册');
  }

  const now = nowIso();
  const info = q.insertUser.run(name, hashPassword(password), 0, now, now);
  const user = q.userById.get(info.lastInsertRowid);

  console.log(`[auth] 新用户注册：${user.username} (#${user.id})`);
  res.status(201).json({ token: signToken(user), user: serializeUser(user) });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') {
    return publicError(res, 400, 'INVALID_INPUT', '请输入用户名和密码');
  }

  const ip = req.ip || 'unknown';
  if (!rateLimit({ key: `login:${ip}:${username.toLowerCase()}`, limit: 10, windowMs: 900_000 })) {
    return publicError(res, 429, 'TOO_MANY_REQUESTS', '尝试次数过多，请 15 分钟后再试');
  }

  const user = q.userByName.get(username.trim());
  if (!user || !verifyPassword(password, user.password_hash)) {
    return publicError(res, 401, 'BAD_CREDENTIALS', '用户名或密码错误');
  }

  freshUser(user);
  res.json({ token: signToken(user), user: serializeUser(user) });
});

/* ------------------------------- 打卡状态 -------------------------------- */

app.get('/api/me', authRequired, (req, res) => {
  const user = freshUser(req.user);
  res.json({ user: serializeUser(user), status: buildStatus(user) });
});

app.get('/api/status', authRequired, (req, res) => {
  const user = freshUser(req.user);
  res.json(buildStatus(user));
});

app.post('/api/checkin', authRequired, (req, res) => {
  const now = new Date();
  const tz = appTimezone();
  const today = dateKey(now, tz);
  const user = freshUser(req.user);

  const existing = q.checkinOn.get(user.id, today);
  if (existing) {
    return res.status(200).json({
      ok: true,
      alreadyCheckedIn: true,
      status: buildStatus(user),
    });
  }

  const deadline = effectiveDeadline(user);
  const late = minutesOfDay(now, tz) >= hhmmToMinutes(deadline) ? 1 : 0;
  const yesterday = addDays(today, -1);
  const continuing = user.last_counted_date === yesterday;
  const nextStreak = continuing ? user.current_streak + 1 : 1;
  const nextBest = Math.max(user.best_streak, nextStreak);
  const note = typeof (req.body || {}).note === 'string' ? String(req.body.note).slice(0, 200) : null;

  const tx = db.transaction(() => {
    q.insertCheckin.run(user.id, today, late, note, now.toISOString());
    q.updateUserBoth.run(nextStreak, nextBest, today, now.toISOString(), user.id);
  });
  tx();

  user.current_streak = nextStreak;
  user.best_streak = nextBest;
  user.last_counted_date = today;

  console.log(
    `[checkin] ${user.username} ${today} late=${late} streak=${nextStreak}`
  );

  res.status(201).json({
    ok: true,
    alreadyCheckedIn: false,
    late: late === 1,
    gainedStreak: nextStreak,
    status: buildStatus(user),
  });
});

app.post('/api/excuse', authRequired, (req, res) => {
  const now = new Date();
  const tz = appTimezone();
  const today = dateKey(now, tz);
  const user = freshUser(req.user);

  const body = req.body || {};
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
  if (reason.length < 2 || reason.length > 300) {
    return publicError(res, 400, 'INVALID_REASON', '请填写 2-300 字的借口说明');
  }

  const targetDate = body.date ? String(body.date) : today;
  if (!DATE_RE.test(targetDate)) {
    return publicError(res, 400, 'INVALID_DATE', '日期格式应为 YYYY-MM-DD');
  }
  const earliest = addDays(today, -EXCUSE_LOOKBACK_DAYS);
  if (targetDate > today || targetDate < earliest) {
    return publicError(
      res,
      400,
      'DATE_OUT_OF_RANGE',
      `只能为最近 ${EXCUSE_LOOKBACK_DAYS} 天内的漏签补填借口`
    );
  }

  const existingCheckin = q.checkinOn.get(user.id, targetDate);
  if (existingCheckin) {
    return publicError(res, 409, 'ALREADY_CHECKED_IN', '该日期已打卡，无需填写借口');
  }

  const existingExcuse = q.excuseOn.get(user.id, targetDate);
  if (existingExcuse) {
    return res.json({ ok: true, alreadyExcused: true, status: buildStatus(user) });
  }

  const tx = db.transaction(() => {
    q.insertExcuse.run(user.id, targetDate, reason, now.toISOString());
    if (!user.last_counted_date || targetDate > user.last_counted_date) {
      q.updateUserStreak.run(user.current_streak, targetDate, now.toISOString(), user.id);
      user.last_counted_date = targetDate;
    }
  });
  tx();

  console.log(`[excuse] ${user.username} ${targetDate} reason=${reason.slice(0, 30)}`);

  res.status(201).json({
    ok: true,
    alreadyExcused: false,
    date: targetDate,
    status: buildStatus(user),
  });
});

/* ------------------------------- 排行榜 ---------------------------------- */

function leaderboardRows() {
  const tz = appTimezone();
  const now = new Date();
  const today = dateKey(now, tz);
  const nowMin = minutesOfDay(now, tz);

  const rows = q.allUsers.all().map((user) => {
    settleUser(user, today, tz);
    const checkin = q.checkinOn.get(user.id, today);
    const excuse = q.excuseOn.get(user.id, today);
    const deadline = effectiveDeadline(user);
    let todayStatus;
    if (checkin) todayStatus = checkin.late === 1 ? 'late' : 'done';
    else if (excuse) todayStatus = 'excused';
    else if (nowMin >= hhmmToMinutes(deadline)) todayStatus = 'missed';
    else todayStatus = 'pending';

    return {
      userId: user.id,
      username: user.username,
      isAdmin: user.is_admin === 1,
      streak: user.current_streak,
      bestStreak: user.best_streak,
      todayStatus,
      deadline,
      lastCountedDate: user.last_counted_date,
      createdAt: user.created_at,
    };
  });

  rows.sort((a, b) => {
    if (b.streak !== a.streak) return b.streak - a.streak;
    if (b.bestStreak !== a.bestStreak) return b.bestStreak - a.bestStreak;
    return String(a.createdAt).localeCompare(String(b.createdAt));
  });

  return rows.map((row, index) => ({ rank: index + 1, ...row }));
}

app.get('/api/leaderboard', authRequired, (req, res) => {
  const limit = Math.min(
    LEADERBOARD_MAX,
    Math.max(1, Number.parseInt(req.query.limit, 10) || 50)
  );
  const all = leaderboardRows();
  const me = req.user.id;

  res.json({
    generatedAt: new Date().toISOString(),
    timezone: appTimezone(),
    total: all.length,
    rows: all
      .slice(0, limit)
      .map((row) => ({ ...row, isMe: row.userId === me })),
    me: all.find((row) => row.userId === me) || null,
  });
});

/* ------------------------------- 设置 ------------------------------------ */

app.get('/api/settings', authRequired, (req, res) => {
  res.json({
    deadline: effectiveDeadline(req.user),
    userDeadline: req.user.deadline,
    defaultDeadline: defaultDeadline(),
    timezone: appTimezone(),
    excuseLookbackDays: EXCUSE_LOOKBACK_DAYS,
  });
});

app.put('/api/settings', authRequired, (req, res) => {
  const body = req.body || {};
  const raw = body.deadline;

  if (raw === null || raw === '' || raw === 'default') {
    q.updateUserDeadline.run(null, nowIso(), req.user.id);
    return res.json({
      ok: true,
      deadline: defaultDeadline(),
      userDeadline: null,
      defaultDeadline: defaultDeadline(),
      timezone: appTimezone(),
    });
  }

  if (typeof raw !== 'string' || !TIME_RE.test(raw)) {
    return publicError(res, 400, 'INVALID_DEADLINE', '截止时间格式应为 HH:MM（00:00 - 23:59）');
  }

  q.updateUserDeadline.run(raw, nowIso(), req.user.id);
  res.json({
    ok: true,
    deadline: raw,
    userDeadline: raw,
    defaultDeadline: defaultDeadline(),
    timezone: appTimezone(),
  });
});

/* --------------------------- 账号自助修改 -------------------------------- */

app.put('/api/account', authRequired, (req, res) => {
  const body = req.body || {};
  const user = req.user;
  const wantsUsername = typeof body.username === 'string' && body.username.trim() !== '';
  const wantsPassword = typeof body.password === 'string' && body.password !== '';

  if (!wantsUsername && !wantsPassword) {
    return publicError(res, 400, 'INVALID_INPUT', '没有需要修改的内容');
  }

  if (wantsPassword && !verifyPassword(String(body.currentPassword || ''), user.password_hash)) {
    return publicError(res, 403, 'BAD_CURRENT_PASSWORD', '当前密码不正确');
  }

  const tx = db.transaction(() => {
    if (wantsUsername) {
      const name = body.username.trim();
      if (!USERNAME_RE.test(name)) {
        throw Object.assign(new Error('用户名需为 2-24 位字母、数字、下划线或中文'), {
          status: 400,
          code: 'INVALID_INPUT',
        });
      }
      const taken = q.userByName.get(name);
      if (taken && taken.id !== user.id) {
        throw Object.assign(new Error('该用户名已被占用'), { status: 409, code: 'USERNAME_TAKEN' });
      }
      q.updateUsername.run(name, nowIso(), user.id);
      user.username = name;
    }
    if (wantsPassword) {
      if (String(body.password).length < 6 || String(body.password).length > 72) {
        throw Object.assign(new Error('密码长度需为 6-72 位'), {
          status: 400,
          code: 'INVALID_INPUT',
        });
      }
      q.updatePassword.run(hashPassword(body.password), nowIso(), user.id);
    }
  });

  try {
    tx();
  } catch (err) {
    return publicError(res, err.status || 400, err.code || 'INVALID_INPUT', err.message);
  }

  res.json({ ok: true, token: signToken(user), user: serializeUser(user) });
});

/* ------------------------------- 管理接口 -------------------------------- */

app.get('/api/admin/users', authRequired, adminRequired, (req, res) => {
  const tz = appTimezone();
  const now = new Date();
  const today = dateKey(now, tz);
  const nowMin = minutesOfDay(now, tz);

  const users = q.allUsers.all().map((user) => {
    settleUser(user, today, tz);
    const checkin = q.checkinOn.get(user.id, today);
    const excuse = q.excuseOn.get(user.id, today);
    let todayStatus = 'pending';
    if (checkin) todayStatus = checkin.late === 1 ? 'late' : 'done';
    else if (excuse) todayStatus = 'excused';
    else if (nowMin >= hhmmToMinutes(effectiveDeadline(user))) todayStatus = 'missed';

    return {
      ...serializeUser(user),
      todayStatus,
      totalCheckins: q.countCheckins.get(user.id).n,
    };
  });

  res.json({ timezone: tz, today, users });
});

/**
 * 管理员重置某个用户的打卡状态（排行榜上的“重置”按钮）
 * body: { date?: 'YYYY-MM-DD', resetStreak?: boolean }
 */
app.post('/api/admin/users/:id/reset', authRequired, adminRequired, (req, res) => {
  const targetId = Number(req.params.id);
  const target = Number.isInteger(targetId) ? q.userById.get(targetId) : null;
  if (!target) return publicError(res, 404, 'USER_NOT_FOUND', '用户不存在');

  const tz = appTimezone();
  const today = dateKey(new Date(), tz);
  const body = req.body || {};
  const date = body.date ? String(body.date) : today;
  if (!DATE_RE.test(date)) {
    return publicError(res, 400, 'INVALID_DATE', '日期格式应为 YYYY-MM-DD');
  }
  const resetStreak = body.resetStreak !== false;

  const tx = db.transaction(() => {
    q.deleteCheckinOn.run(target.id, date);
    q.deleteExcuseOn.run(target.id, date);
    if (resetStreak) {
      q.updateUserStreak.run(0, null, nowIso(), target.id);
      target.current_streak = 0;
      target.last_counted_date = null;
    }
    q.audit.run(
      req.user.id,
      'RESET_CHECKIN',
      target.id,
      JSON.stringify({ date, resetStreak }),
      nowIso()
    );
  });
  tx();

  console.log(`[admin] ${req.user.username} 重置了 ${target.username} 的 ${date} 记录`);

  const refreshed = q.userById.get(target.id);
  res.json({
    ok: true,
    date,
    user: serializeUser(refreshed),
    status: buildStatus(refreshed),
  });
});

/** 管理员修改全局设置（默认截止时间 / 时区） */
app.put('/api/admin/settings', authRequired, adminRequired, (req, res) => {
  const body = req.body || {};
  const patch = {};

  if (body.defaultDeadline !== undefined) {
    if (!TIME_RE.test(String(body.defaultDeadline))) {
      return publicError(res, 400, 'INVALID_DEADLINE', '默认截止时间格式应为 HH:MM');
    }
    patch.default_deadline = String(body.defaultDeadline);
  }
  if (body.timezone !== undefined) {
    if (!isValidTimeZone(String(body.timezone))) {
      return publicError(res, 400, 'INVALID_TIMEZONE', '无效的时区，例如 Asia/Shanghai');
    }
    patch.timezone = String(body.timezone);
  }
  if (!Object.keys(patch).length) {
    return publicError(res, 400, 'INVALID_INPUT', '没有需要修改的设置');
  }

  for (const [key, value] of Object.entries(patch)) q.setSetting.run(key, value);
  q.audit.run(req.user.id, 'UPDATE_SETTINGS', null, JSON.stringify(patch), nowIso());

  res.json({
    ok: true,
    defaultDeadline: defaultDeadline(),
    timezone: appTimezone(),
  });
});

/* ------------------------------- 静态资源 -------------------------------- */

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: '1h' }));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use('/api', (req, res) => {
  publicError(res, 404, 'NOT_FOUND', '接口不存在');
});

/* ------------------------------- 错误处理 -------------------------------- */

app.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') {
    return publicError(res, 400, 'INVALID_JSON', '请求体不是合法的 JSON');
  }
  if (err && err.type === 'entity.too.large') {
    return publicError(res, 413, 'PAYLOAD_TOO_LARGE', '请求体过大');
  }
  console.error('[error]', err);
  if (res.headersSent) return next(err);
  publicError(res, 500, 'INTERNAL_ERROR', '服务器开小差了，请稍后再试');
});

/* --------------------------------------------------------------------------
 * 10. 启动
 * ------------------------------------------------------------------------ */

seed();

const server = app.listen(PORT, HOST, () => {
  console.log('──────────────────────────────────────────────');
  console.log('  防拖延强制打卡系统 · 后端已启动');
  console.log(`  HTTP      http://localhost:${PORT}`);
  console.log(`  Web 管理端 http://localhost:${PORT}/`);
  console.log(`  数据库     ${DB_PATH}`);
  console.log(`  时区       ${appTimezone()}   默认截止 ${defaultDeadline()}`);
  console.log(`  环境       ${NODE_ENV}`);
  console.log('──────────────────────────────────────────────');
});

function shutdown(signal) {
  console.log(`\n[shutdown] 收到 ${signal}，正在关闭...`);
  server.close(() => {
    try {
      db.close();
    } catch (err) {
      console.error(err);
    }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

module.exports = app;
